﻿#include <cuda_runtime.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

static void cudaCheck(cudaError_t e, const char* expr, int line) {
    if (e != cudaSuccess)
        throw std::runtime_error(std::string(expr) + " at line " +
            std::to_string(line) + ": " + cudaGetErrorString(e));
}
#define CUDA_CHECK(expr) cudaCheck((expr), #expr, __LINE__)

template<class T> class DeviceArray {
public:
    T* data = nullptr;
    explicit DeviceArray(size_t n) {
        CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&data), n * sizeof(T)));
    }
    ~DeviceArray() { if (data) cudaFree(data); }
    DeviceArray(const DeviceArray&) = delete;
    DeviceArray& operator=(const DeviceArray&) = delete;
};

class Event {
public:
    cudaEvent_t value;
    Event() { CUDA_CHECK(cudaEventCreate(&value)); }
    ~Event() { cudaEventDestroy(value); }
    Event(const Event&) = delete;
    Event& operator=(const Event&) = delete;
};

// Each thread produces one P[row,col]. M is j*k, N is k*l, P is j*l.
__global__ void mmultNaive(const float* M, const float* N, float* P,
    int j, int k, int l) {
    const int row = blockIdx.y * blockDim.y + threadIdx.y;
    const int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row >= j || col >= l) return;
    float sum = 0.0f;
    for (int t = 0; t < k; ++t)
        sum += M[static_cast<size_t>(row) * k + t] *
        N[static_cast<size_t>(t) * l + col];
    P[static_cast<size_t>(row) * l + col] = sum;
}

template<int TILE> __global__ void mmultTiled(
    const float* M, const float* N, float* P, int j, int k, int l) {
    __shared__ float Ms[TILE][TILE];
    __shared__ float Ns[TILE][TILE];
    const int tx = threadIdx.x, ty = threadIdx.y;
    const int row = blockIdx.y * TILE + ty;
    const int col = blockIdx.x * TILE + tx;
    float sum = 0.0f;
    for (int phase = 0; phase < (k + TILE - 1) / TILE; ++phase) {
        const int mcol = phase * TILE + tx;
        const int nrow = phase * TILE + ty;
        Ms[ty][tx] = (row < j && mcol < k)
            ? M[static_cast<size_t>(row) * k + mcol] : 0.0f;
        Ns[ty][tx] = (nrow < k && col < l)
            ? N[static_cast<size_t>(nrow) * l + col] : 0.0f;
        // Even out-of-range output threads participate in both barriers.
        __syncthreads();
        for (int t = 0; t < TILE; ++t) sum += Ms[ty][t] * Ns[t][tx];
        __syncthreads(); // Prevent next phase from overwriting tiles in use.
    }
    if (row < j && col < l) P[static_cast<size_t>(row) * l + col] = sum;
}

// Separate non-inlined functions with runtime loops encourage real control
// flow rather than a short predicated expression. Verify generated SASS/NCU:
// source-level branches alone do not prove hardware branch divergence.
__device__ __noinline__ float path0(float x, int iterations) {
    for (int i = 0; i < iterations; ++i) x = __fmaf_rn(x, 0.9991f, 0.0011f);
    return x;
}
__device__ __noinline__ float path1(float x, int iterations) {
    for (int i = 0; i < iterations; ++i) x = __fmaf_rn(x, 0.9987f, 0.0019f);
    return x;
}
__device__ __noinline__ float path2(float x, int iterations) {
    for (int i = 0; i < iterations; ++i) x = __fmaf_rn(x, 0.9993f, 0.0009f);
    return x;
}

__global__ void divergenceSingle(const unsigned* tags, float* output,
    size_t n, int iterations) {
    const size_t id = static_cast<size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (id >= n) return;
    const float x = 0.25f + float(id % 17) * 0.01f;
    if (tags[id] == 0) output[id] = path0(x, iterations);
    else               output[id] = path1(x, iterations);
}

__global__ void divergenceNested(const unsigned* tags, float* output,
    size_t n, int iterations) {
    const size_t id = static_cast<size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (id >= n) return;
    const float x = 0.25f + float(id % 17) * 0.01f;
    if (tags[id] == 0) {
        output[id] = path0(x, iterations);
    }
    else {
        if (tags[id] == 1) output[id] = path1(x, iterations);
        else               output[id] = path2(x, iterations);
    }
}

struct Options {
    std::string mode, kernel = "both", kind = "single", pattern = "divergent";
    int caseId = 1, tile = 16, repeats = 10, warmup = 2;
    int threads = 196608, iterations = 128;
    bool profile = false;
};

static void help() {
    std::cout <<
        "HW3 usage:\n"
        "  hw3 mmult [--case 1|2|3] [--kernel naive|tiled|both]\n"
        "            [--tile 8|12|16|32] [--repeats N] [--warmup N]\n"
        "  hw3 divergence [--kind single|nested]\n"
        "                 [--pattern divergent|uniform] [--threads N]\n"
        "                 [--iterations N] [--repeats N] [--warmup N]\n"
        "  Add --profile to either command: exactly ONE kernel launch,\n"
        "  no warmup, no host console output, and no CPU verification.\n"
        "  mmult --profile requires --kernel naive or --kernel tiled.\n"
        "  Run normal verification BEFORE collecting profiles.\n"
        "  For divergence N must be a multiple of 256; a multiple of 768\n"
        "  gives equal path populations in both patterns for both kernels.\n"
        "Examples:\n"
        "  hw3 mmult --case 1 --kernel both --tile 16\n"
        "  hw3 mmult --case 3 --kernel tiled --tile 32 --profile\n"
        "  hw3 divergence --kind nested --pattern uniform\n";
}

static int parseInt(const std::string& text) {
    size_t used = 0;
    const long long v = std::stoll(text, &used);
    if (used != text.size() || v < 0 || v > std::numeric_limits<int>::max())
        throw std::runtime_error("Invalid nonnegative integer: " + text);
    return static_cast<int>(v);
}

static Options parse(int argc, char** argv) {
    Options o;
    o.mode = argv[1];
    if (o.mode != "mmult" && o.mode != "divergence")
        throw std::runtime_error("Mode must be mmult or divergence; use --help.");
    for (int i = 2; i < argc; ++i) {
        const std::string key = argv[i];
        if (key == "--profile") { o.profile = true; continue; }
        if (i + 1 >= argc) throw std::runtime_error("Missing value for " + key);
        const std::string val = argv[++i];
        if (key == "--case" && o.mode == "mmult") o.caseId = parseInt(val);
        else if (key == "--tile" && o.mode == "mmult") o.tile = parseInt(val);
        else if (key == "--kernel" && o.mode == "mmult") o.kernel = val;
        else if (key == "--kind" && o.mode == "divergence") o.kind = val;
        else if (key == "--pattern" && o.mode == "divergence") o.pattern = val;
        else if (key == "--threads" && o.mode == "divergence") o.threads = parseInt(val);
        else if (key == "--iterations" && o.mode == "divergence") o.iterations = parseInt(val);
        else if (key == "--repeats") o.repeats = parseInt(val);
        else if (key == "--warmup") o.warmup = parseInt(val);
        else throw std::runtime_error("Unknown option for this mode: " + key);
    }
    if (o.caseId < 1 || o.caseId > 3 ||
        (o.tile != 8 && o.tile != 12 && o.tile != 16 && o.tile != 32) ||
        (o.kernel != "naive" && o.kernel != "tiled" && o.kernel != "both") ||
        (o.kind != "single" && o.kind != "nested") ||
        (o.pattern != "divergent" && o.pattern != "uniform") ||
        o.repeats < 1 || o.threads < 256 || o.threads % 256 != 0 || o.iterations < 1)
        throw std::runtime_error("Invalid option value; use --help.");
    if (o.profile && o.mode == "mmult" && o.kernel == "both")
        throw std::runtime_error("--profile requires one --kernel: naive or tiled.");
    return o;
}

template<class Launch> static float timeKernel(const Options& o, Launch launch) {
    if (o.profile) {
        launch();
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaDeviceSynchronize());
        return 0.0f;
    }
    for (int i = 0; i < o.warmup; ++i) launch();
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
    Event start, stop;
    CUDA_CHECK(cudaEventRecord(start.value));
    for (int i = 0; i < o.repeats; ++i) launch();
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaEventRecord(stop.value));
    CUDA_CHECK(cudaEventSynchronize(stop.value));
    float elapsed;
    CUDA_CHECK(cudaEventElapsedTime(&elapsed, start.value, stop.value));
    return elapsed / o.repeats; // Kernel-only average, excluding transfers/CPU.
}

struct Errors {
    double maxAbs = 0.0, maxRelative = 0.0;
    size_t failed = 0, worstRelativeIndex = 0;
};
static Errors compare(const std::vector<float>& ref, const std::vector<float>& got) {
    Errors e;
    const double atol = 1e-5, rtol = 1e-4;
    for (size_t i = 0; i < ref.size(); ++i) {
        const double difference = std::abs(double(ref[i]) - got[i]);
        const double denominator = std::abs(double(ref[i]));
        // Positive MMULT inputs make ref > 0; zero is handled explicitly.
        const double rel = denominator != 0.0 ? difference / denominator
            : (difference == 0.0 ? 0.0 : std::numeric_limits<double>::infinity());
        if (!std::isfinite(got[i])) {
            ++e.failed;
            e.maxAbs = e.maxRelative = std::numeric_limits<double>::infinity();
            e.worstRelativeIndex = i;
            continue;
        }
        e.maxAbs = std::max(e.maxAbs, difference);
        if (rel > e.maxRelative) { e.maxRelative = rel; e.worstRelativeIndex = i; }
        if (difference > atol + rtol * denominator) ++e.failed;
    }
    return e;
}

static void printErrors(const Errors& e) {
    std::cout << std::scientific << "max_abs_error=" << e.maxAbs
        << " max_abs_error_fraction=" << e.maxRelative
        << " worst_flat_index=" << e.worstRelativeIndex
        << " failed_elements=" << e.failed << '\n';
}

static void cpuMmult(const std::vector<float>& M, const std::vector<float>& N,
    std::vector<float>& P, int j, int k, int l) {
    // Serial reference with FP64 accumulation, rounded to FP32 output.
    // i-t-col order keeps N accesses contiguous and makes large tests practical.
    std::vector<double> row(l);
    for (int i = 0; i < j; ++i) {
        std::fill(row.begin(), row.end(), 0.0);
        for (int t = 0; t < k; ++t) {
            const double m = M[static_cast<size_t>(i) * k + t];
            for (int col = 0; col < l; ++col)
                row[col] += m * N[static_cast<size_t>(t) * l + col];
        }
        for (int col = 0; col < l; ++col)
            P[static_cast<size_t>(i) * l + col] = static_cast<float>(row[col]);
    }
}

static void launchMmult(const Options& o, bool tiled, dim3 grid, dim3 block,
    const float* M, const float* N, float* P, int j, int k, int l) {
    if (!tiled) { mmultNaive << <grid, block >> > (M, N, P, j, k, l); return; }
    switch (o.tile) {
    case 8:  mmultTiled<8> << <grid, block >> > (M, N, P, j, k, l); break;
    case 12: mmultTiled<12> << <grid, block >> > (M, N, P, j, k, l); break;
    case 16: mmultTiled<16> << <grid, block >> > (M, N, P, j, k, l); break;
    case 32: mmultTiled<32> << <grid, block >> > (M, N, P, j, k, l); break;
    }
}

static bool runMmult(const Options& o, const cudaDeviceProp& props) {
    const int js[] = { 100, 1000, 2000 }, ks[] = { 100, 1000, 2500 }, ls[] = { 100, 1000, 3000 };
    const int j = js[o.caseId - 1], k = ks[o.caseId - 1], l = ls[o.caseId - 1];
    if (o.tile * o.tile > props.maxThreadsPerBlock ||
        o.tile > props.maxThreadsDim[0] || o.tile > props.maxThreadsDim[1] ||
        2 * o.tile * o.tile * sizeof(float) > props.sharedMemPerBlock)
        throw std::runtime_error("Tile/block exceeds device limits.");
    const dim3 block(o.tile, o.tile), grid((l + o.tile - 1) / o.tile, (j + o.tile - 1) / o.tile);
    std::vector<float> M(static_cast<size_t>(j) * k), N(static_cast<size_t>(k) * l);
    std::mt19937 random(568);
    std::uniform_real_distribution<float> value(0.1f, 1.0f);
    for (float& x : M) x = value(random);
    for (float& x : N) x = value(random);
    DeviceArray<float> dM(M.size()), dN(N.size()), dP(static_cast<size_t>(j) * l);
    CUDA_CHECK(cudaMemcpy(dM.data, M.data(), M.size() * sizeof(float), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(dN.data, N.data(), N.size() * sizeof(float), cudaMemcpyHostToDevice));
    std::vector<float> reference, result;
    if (!o.profile) {
        reference.resize(static_cast<size_t>(j) * l);
        result.resize(reference.size());
        const auto begin = std::chrono::steady_clock::now();
        cpuMmult(M, N, reference, j, k, l);
        const double ms = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - begin).count();
        std::cout << "M=" << j << 'x' << k << " N=" << k << 'x' << l
            << " P=" << j << 'x' << l << " CPU_serial_ms=" << ms << '\n';
    }
    bool ok = true;
    for (bool tiled : {false, true}) {
        if ((!tiled && o.kernel == "tiled") || (tiled && o.kernel == "naive")) continue;
        const float ms = timeKernel(o, [&]() {
            launchMmult(o, tiled, grid, block, dM.data, dN.data, dP.data, j, k, l);
            });
        if (o.profile) continue;
        CUDA_CHECK(cudaMemcpy(result.data(), dP.data, result.size() * sizeof(float), cudaMemcpyDeviceToHost));
        const Errors errors = compare(reference, result);
        ok = ok && errors.failed == 0;
        // Useful mathematical work; padding arithmetic is not counted here.
        const double flops = 2.0 * j * k * l;
        std::cout << std::fixed << std::setprecision(6)
            << "kernel=" << (tiled ? "tiled" : "naive") << " tile=" << o.tile
            << " grid=" << grid.x << 'x' << grid.y << " block=" << block.x << 'x' << block.y
            << " mean_kernel_ms=" << ms << " useful_GFLOP_per_s=" << flops / (ms * 1.0e6) << '\n';
        printErrors(errors);
    }
    return ok;
}

static bool runDivergence(const Options& o, const cudaDeviceProp& props) {
    const int paths = o.kind == "single" ? 2 : 3;
    const size_t n = static_cast<size_t>(o.threads);
    const unsigned blocks = static_cast<unsigned>(n / 256);
    if (props.warpSize != 32 || props.maxThreadsPerBlock < 256 ||
        blocks > static_cast<unsigned>(props.maxGridSize[0]))
        throw std::runtime_error("Divergence experiment requires 32-lane warps and a legal 256-thread block grid.");
    std::vector<unsigned> tags(n);
    for (size_t i = 0; i < n; ++i)
        tags[i] = static_cast<unsigned>((o.pattern == "divergent" ? i : i / 32) % paths);
    DeviceArray<unsigned> dTags(n);
    DeviceArray<float> dOutput(n);
    CUDA_CHECK(cudaMemcpy(dTags.data, tags.data(), n * sizeof(unsigned), cudaMemcpyHostToDevice));
    const float ms = timeKernel(o, [&]() {
        if (o.kind == "single")
            divergenceSingle << <blocks, 256 >> > (dTags.data, dOutput.data, n, o.iterations);
        else divergenceNested << <blocks, 256 >> > (dTags.data, dOutput.data, n, o.iterations);
        });
    if (o.profile) return true;
    std::vector<float> got(n), reference(n);
    CUDA_CHECK(cudaMemcpy(got.data(), dOutput.data, n * sizeof(float), cudaMemcpyDeviceToHost));
    const float a[] = { 0.9991f, 0.9987f, 0.9993f }, b[] = { 0.0011f, 0.0019f, 0.0009f };
    for (size_t i = 0; i < n; ++i) {
        float x = 0.25f + float(i % 17) * 0.01f;
        for (int t = 0; t < o.iterations; ++t) x = std::fma(x, a[tags[i]], b[tags[i]]);
        reference[i] = x;
    }
    const Errors errors = compare(reference, got);
    std::cout << "kind=" << o.kind << " pattern=" << o.pattern << " threads=" << n
        << " blocks=" << blocks << " block=256 iterations=" << o.iterations
        << " mean_kernel_ms=" << ms << '\n';
    if (n % 768 != 0)
        std::cout << "Note: use --threads multiple-of-768 for balanced path populations.\n";
    printErrors(errors);
    return errors.failed == 0;
}

int main(int argc, char** argv) {
    try {
        if (argc < 2 || std::string(argv[1]) == "--help") { help(); return 0; }
        const Options o = parse(argc, argv);
        CUDA_CHECK(cudaSetDevice(0));
        cudaDeviceProp props;
        CUDA_CHECK(cudaGetDeviceProperties(&props, 0));
        if (!o.profile) std::cout << "GPU=" << props.name << " SMs=" << props.multiProcessorCount
            << " max_threads_per_block=" << props.maxThreadsPerBlock << '\n';
        const bool ok = o.mode == "mmult" ? runMmult(o, props) : runDivergence(o, props);
        if (!o.profile) std::cout << (ok ? "Verification: PASS\n" : "Verification: FAIL\n");
        return ok ? 0 : 2;
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << '\n';
        return 1;
    }
}
